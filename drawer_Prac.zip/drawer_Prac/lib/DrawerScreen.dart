import 'package:flutter/material.dart';

class DrawerScreen extends StatefulWidget {
  const DrawerScreen({super.key});

  @override
  State<DrawerScreen> createState() => _DrawerScreenState();
}

class _DrawerScreenState extends State<DrawerScreen> {
  List<String> appbar = [
    'Home',
    'Help Center',
    'About Us'
  ];
  List drawerContent = [
    Text(
      'Home',
      style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold),
    ),
    Text(
      'Help Center',
      style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold),
    ),
    Text(
      'About Us',
      style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold),
    ),
  ];

  int _selectedIndex = 0;

  void onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          appbar[_selectedIndex],
          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 30),
        ),
      ),
      body: Center(child: drawerContent[_selectedIndex]),
      drawer: Drawer(
        child: ListView(
          children: [
            DrawerHeader(
                decoration: BoxDecoration(color: Colors.blue),
                child: Text(
                  'Drawer Header',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 30),
                )),
            ListTile(
              onTap: () {
                onItemTapped(0);
                Navigator.pop(context);
              },
              selected: _selectedIndex == 0,
              leading: Icon(Icons.home),
              title: Text(
                'Home',
                style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
              ),
            ),
            ListTile(
              onTap: () {
                onItemTapped(1);
                Navigator.pop(context);
              },
              selected: _selectedIndex == 1,
              leading: Icon(Icons.help_center),
              title: Text(
                'Help Center',
                style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
              ),
            ),
            ListTile(
              onTap: () {
                onItemTapped(2);
                Navigator.pop(context);
              },
              selected: _selectedIndex == 2,
              leading: Icon(Icons.menu),
              title: Text(
                'About Us',
                style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
              ),
            )
          ],
        ),
      ),
    );
  }
}
