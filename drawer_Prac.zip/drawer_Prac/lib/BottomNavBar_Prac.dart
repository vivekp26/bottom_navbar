import 'package:flutter/material.dart';

class BottomNavBar extends StatefulWidget {
  const BottomNavBar({super.key});

  @override
  State<BottomNavBar> createState() => _BottomNavBarState();
}

class _BottomNavBarState extends State<BottomNavBar> {
  // static const List<Widget> content = [
  //   Text('Home',style: TextStyle(fontSize: 30,fontWeight: FontWeight.bold),),
  //   Text('Help',style: TextStyle(fontSize: 30,fontWeight: FontWeight.bold),),
  //   Text('About Us',style: TextStyle(fontSize: 30,fontWeight: FontWeight.bold),),
  //   // Text('Shopping',style: TextStyle(fontSize: 30,fontWeight: FontWeight.bold),),
  // ];
  List<String> appbar = [
    'HomePage',
    'Help Center',
    'About Us'
  ];
  List<String> content = [
    'Home',
    'Help',
    'About Us',
  ];
  int myIndex = 0;
  void onItemTapped(int index){
    setState(() {
      myIndex = index;
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(appbar[myIndex],style: TextStyle(fontSize: 30,fontWeight: FontWeight.bold),),),
      bottomNavigationBar: BottomNavigationBar(
        selectedLabelStyle:  TextStyle(fontSize:20,color: Colors.blue,fontWeight: FontWeight.bold),
        unselectedLabelStyle: TextStyle(fontSize:20,color: Colors.blue,fontWeight: FontWeight.bold),
        selectedIconTheme: IconThemeData(color: Colors.blue),
        iconSize: 30,
        // elevation: 10,
        backgroundColor: Colors.grey.shade300,
        fixedColor: Colors.black,
        currentIndex: myIndex,
        onTap: (index){
          setState(() {
            myIndex = index;
          });
        },
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.home),label: 'Home',),
          BottomNavigationBarItem(icon: Icon(Icons.help_center),label: 'Help'),
          BottomNavigationBarItem(icon: Icon(Icons.menu),label: 'AboutUs'),
          // BottomNavigationBarItem(icon: Icon(Icons.shopping_cart),label: 'Shopping'),
        ],
      ),
      body: Center(
        child: Text(content[myIndex],style: TextStyle(fontSize: 30,fontWeight: FontWeight.bold),),
      ),
    );
  }
}
