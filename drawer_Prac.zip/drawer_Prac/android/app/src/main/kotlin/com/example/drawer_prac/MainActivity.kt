package com.example.drawer_prac

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
